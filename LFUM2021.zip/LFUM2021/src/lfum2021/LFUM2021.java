/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lfum2021;

import java.awt.Desktop;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.text.DateFormatSymbols;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Locale;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.net.ssl.HttpsURLConnection;

/**
 *
 * @author prueba
 */
public class LFUM2021 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        String opcion = "";

        do {
            try {
                System.out.flush();
                System.out.println("");
                System.out.println("Digíte");
                System.out.println("1: convertir número 10 digítos a letras");
                System.out.println("2: producto de abc de esta triple pitagórica en especifico");
                System.out.println("3: cliente REST que consuma el siguiente WebService");
                System.out.println("4: archivo calendario para el mes");
                System.out.println("0: finalizar");
                System.out.println("");
                Scanner scanner = new Scanner(System.in);
                opcion = scanner.next();
                switch (opcion.charAt(0)) {
                    case '1':
                        System.out.flush();
                        System.out.println("Digíte número 10 digítos");
                        String opcion1 = scanner.next();
                        System.out.println(LFUM2021.convertirALetras(Long.parseLong(opcion1)));
                        break;
                    case '2':
                        LFUM2021.encontrarTriplePitagoricaEspecifica();
                        break;
                    case '3':
                        LFUM2021.consumeUrlWithUserNameAndPassword();
                        break;
                    case '4':
                        System.out.flush();
                        System.out.println("Digíte numero del mes");
                        String opcion4 = scanner.next();
                        int mes = Integer.parseInt(opcion4);
                        System.out.println("Digíte letra del primer día del mes");
                        opcion4 = scanner.next();
                        char primerDia = opcion4.charAt(0);
                        LFUM2021.escribirMes(mes, primerDia);
                        break;
                    default:
                        throw new AssertionError();
                }
            } catch (Exception e) {

            }
        } while (!("0".equals(opcion)));

    }

//Desarrolle un programa que reciba como parametro un numero de 10 digitos y lo convierta a letras de acuerdo a la siguiente definición:
//Ejemplo: Parametro: 0055667788 ---> SSGGMMEELL El programa debe arrojar un excepción en caso de que se ingrese un numero de menos de 10 digito o mas de 10 digitos
    private static final int S = 0;
    private static final int U = 1;
    private static final int T = 2;
    private static final int P = 3;
    private static final int A = 4;
    private static final int G = 5;
    private static final int M = 6;
    private static final int E = 7;
    private static final int L = 8;
    private static final int C = 9;

    static private String convertirALetras(Long convertirALetras) {
        String textoEntrada = convertirALetras.toString();
        assert textoEntrada.length() == 10;
        StringBuilder toReturn = new StringBuilder();
        for (int i = 0; i < textoEntrada.length(); i++) {
            int letra = Integer.parseInt(textoEntrada.charAt(i) + "");
            switch (letra) {
                case S:
                    toReturn.append("S");
                    break;
                case U:
                    toReturn.append("U");
                    break;
                case T:
                    toReturn.append("T");
                    break;
                case P:
                    toReturn.append("P");
                    break;
                case A:
                    toReturn.append("A");
                    break;
                case G:
                    toReturn.append("G");
                    break;
                case M:
                    toReturn.append("M");
                    break;
                case E:
                    toReturn.append("E");
                    break;
                case L:
                    toReturn.append("L");
                    break;
                case C:
                    toReturn.append("C");
                    break;
                default:
                    toReturn.append("");
                    break;
            }

        }
        return toReturn.toString();

    }

//Desarrolle un programa que calcule el valor correcto del siguiente problema.
//El valor puede ser presentado en pantalla de línea de comandos, no se requiere interface gráfica.
//
//Problema:
//
//Una tripleta pitagórica es un conjunto de tres números naturales (enteros positivos),
// a < b < c, para los cuales:
//
//a2 + b2 = c2
//
//Por ejemplo, 32+ 42 = 9 + 16 = 25 = 52
//
//Existe exactamente una tripleta pitagórica para la cual a + b + c = 1000.
//
//Encontrar el producto de abc de esta triple pitagórica en especifico.
    static void encontrarTriplePitagoricaEspecifica() {
        int a = 0, b = 1, c = 2, total = 1000, sumatoria = a + b + c;
        do {
            a++;
            b++;
            c++;
            a *= a;
            b *= b;
            c *= c;
            sumatoria = a + b + c;
        } while (sumatoria < total);
        String tripleta = String.format("Tripleta pitagórica : a= %1$s, b= %1$s c=%2$s", a, b, c);
        System.out.println(tripleta);
    }

//Desarrolle un cliente REST que consuma el siguiente WebService,
// OPCIONALMENTE presente el resultado en un Frontend html basico.
//
//Documentación de consumo: https://securetransfer.redsis.com/rest/forms/v1/teamGoAny/payload?help=true
//User: ingresoRedsis
//Password: Qwerty0909$
    static private void consumeUrlWithUserNameAndPassword() {

        try {
            URL url = new URL("https://securetransfer.redsis.com/rest/forms/v1/teamGoAny/payload");
            HttpsURLConnection connection = (HttpsURLConnection) url.openConnection();
            connection.setRequestMethod("GET");
            //connection.setRequestProperty("Authorization", "Basic " + Base64.encode(("ingresoRedsis" + ":" + "Qwerty0909$").getBytes()));
            connection.setRequestProperty("content-type", "text/xml; charset=UTF-8");

            connection.setConnectTimeout(10000);
            //TODO: javax.net.ssl.SSLHandshakeException: Received fatal alert: handshake_failure
            connection.connect();
            BufferedReader in = new BufferedReader(
                    new InputStreamReader(connection.getInputStream()));
            String inputLine;
            StringBuffer content = new StringBuffer();
            while ((inputLine = in.readLine()) != null) {
                content.append(inputLine);
            }
            in.close();
            connection.disconnect();

            BufferedWriter bwr = new BufferedWriter(new FileWriter(new File("C:\\Users\\prueba\\Desktop\\lfum2021.html")));

            //write contents of StringBuffer to a file
            bwr.write(content.toString());

            //flush the stream
            bwr.flush();

            //close the stream
            bwr.close();

            File htmlFile = new File("C:/lfum2021.html");
            Desktop.getDesktop().browse(htmlFile.toURI());
        } catch (Exception ex) {
            Logger.getLogger(LFUM2021.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    //Desarrolle un programa que contenga un método, de nombre escribirMes,
    // que reciba por parámetro el número correspondiente a un mes del año y la
    // letra correspondiente al día de la semana en que cae el día 1 de ese mes
    // (‘L’ para lunes, ‘M’ para martes, ‘X’ para miércoles…).
    // El método escribirá en un archivo un calendario para ese mes, que estará
    // formado por todos los días del mes seguidos de la letra correspondiente
    // al día de la semana en que caen. El método comprobará que los parámetros
    // recibidos son correctos y obtendrá el nombre, concatenando a la palabra
    // mes el número de mes recibido como extensión.
    //
    //Ejemplo: Si el método recibe el valor 3 (que representa el mes de marzo),
    // y la letra ‘M’, indicando que el 1 de marzo es martes,
    // el método obtendrá el nombre de archivo “mes3.txt” y lo escribirá con un calendario así:
    //
    //1M2X3J4V5S…………………….31J
    static private void escribirMes(int mes, char primerdia) {
        BufferedWriter bwr = null;
        try {
            // TODO: Nombre del mes en español
            DateFormatSymbols symbols = new DateFormatSymbols(Locale.getDefault());
            String[] weekDays = symbols.getWeekdays();
            StringBuilder content = new StringBuilder();
            Calendar calendar = new GregorianCalendar(2021, mes - 1, 1);
            System.out.println("escribirMes");
            int daysInMonth = calendar.getActualMaximum(Calendar.DAY_OF_MONTH); // 28
            int day = 1;
            int weekDay = -1;
            for (int i = 1; i <= 7; i++) {
                if(weekDays[i].charAt(0) == primerdia){
                    weekDay = i;
                    break;
                }
            }
            System.out.println("escribirMes "+ weekDay);
            while (day <= daysInMonth) {
                content.append(day).append("").append(weekDays[weekDay].charAt(0));
                weekDay = weekDay > 7 ? 0 : weekDay + 1;
                day++;
            }
            System.out.println(content.toString());
            bwr = new BufferedWriter(new FileWriter(new File(String.format("C:\\Users\\prueba\\Desktop\\mes%s.txt", mes))));
            //write contents of StringBuffer to a file
            bwr.write(content.toString());
            //flush the stream
            bwr.flush();
            //close the stream
            bwr.close();
        } catch (Exception ex) {
            System.out.println(ex);
            Logger.getLogger(LFUM2021.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                if(bwr!=null)
                    bwr.close();
            } catch (IOException ex) {
                Logger.getLogger(LFUM2021.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

}
